public class Night extends Piece {
    int value;
    public Night(String color){
        value = 3;
        this.color = color;
    }
}
