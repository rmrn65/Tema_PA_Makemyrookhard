
public class King extends Piece{
    public King(String color){
        this.color = color;
    }
}
