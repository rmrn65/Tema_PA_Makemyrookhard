public class Piece {
    String color;
    String current_position;
    public Piece(){}
}
