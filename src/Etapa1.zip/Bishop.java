
public class Bishop extends Piece{
    int value;
    public Bishop(String color){
        value = 3;
        this.color = color;
    }
}
