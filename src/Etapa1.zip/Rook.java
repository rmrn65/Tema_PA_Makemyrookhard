public class Rook extends Piece{
    int value;
    public Rook(String color){
        value = 5;
        this.color = color;
    }
}
