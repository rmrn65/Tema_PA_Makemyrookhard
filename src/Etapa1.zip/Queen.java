public class Queen extends Piece{
    int value;
    public Queen(String color){
        value = 9;
        this.color = color;
    }
}
